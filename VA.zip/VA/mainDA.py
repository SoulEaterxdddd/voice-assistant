from PyQt5 import QtWidgets
from PyQt5 import QtCore
from untitledd import Ui_vwindow
from AV import huilo
import sys

huil = huilo()

# Для перевода файла QT в файл .py:
# pyuic5 untitled.ui -o untitled.py
# untitled - имя файла

class untitled(QtWidgets.QMainWindow):
    def __init__(self):
        self.h = 0
        #Присоединение окна
        super(untitled, self).__init__()
        self.ui = Ui_vwindow()
        self.ui.setupUi(self)


        #Присоединение функций к кнопкам (нажатие на кнопку срабатывает функцию в скобках
        self.ui.ButtonStrelka1.clicked.connect(self.Na2Slaid)
        self.ui.ButtonStrelka2.clicked.connect(self.Obratno_1_slaid)
        self.ui.ButtonMogu.clicked.connect(self.Na_3_Slaid)
        self.ui.Strelka_Nazad.clicked.connect(self.Na_1_slaid_s3)
        self.ui.Strelka_Nazad_2.clicked.connect(self.Na_3_Slaid)
        self.ui.Znak_voprosa.clicked.connect(self.Znak_voprosa)
        self.ui.MicroPhone.clicked.connect(self.microphone)
        self.ui.MicroPhone2.clicked.connect(self.microphone2)
        self.ui.vihod.clicked.connect(self.vihodi)
        self.av = huil.AVa


        self.alk = 0

    def vihodi(self):
        sys.exit()

    def microphone(self):
        self.ui.MicroPhone.close()
        self.ui.MicroPhone2.show()
        self.ui.label_loh.close()
        self.ui.label_loh2.show()
        self.ui.label_loh3.close()
        if self.h == 0:
            self.av()


    def microphone2(self):
        self.ui.MicroPhone.show()
        self.ui.MicroPhone2.close()
        self.ui.label_loh2.close()
        self.ui.label_loh3.show()
        self.h = 1


    def Na2Slaid(self):
        if self.alk == 0:
            # Закрытие 1 слайда
            self.ui.ButtonStrelka1.close()
            self.ui.ButtonAV.setGeometry(QtCore.QRect(300, 0, 200, 191))
            self.ui.label_Privet.close()
            # Открытие 2 слайда
            self.ui.ButtonAV.show()
            self.ui.ButtonMogu.show()
            self.ui.label_Mogu.show()
            self.ui.ButtonStrelka2.show()

        if self.alk == 1:
            # Закрытие 1 слайда
            self.ui.ButtonStrelka1.close()
            self.ui.ButtonAV.close()
            self.ui.label_Privet.close()
            # Открытие 3 слайда
            self.ui.vihod.show()
            self.ui.label_loh.show()
            self.ui.Strelka_Nazad.show()
            self.ui.Linia_Slaid_3.show()
            self.ui.Znak_voprosa.show()
            self.ui.Otkritb_Text.show()
            self.ui.MicroPhone.show()


    def Obratno_1_slaid(self):
        # Закрытие 2 слайда
        self.ui.ButtonAV.setGeometry(QtCore.QRect(300, 50, 200, 191))
        self.ui.ButtonMogu.close()
        self.ui.label_Mogu.close()
        self.ui.ButtonStrelka2.close()
        self.ui.MicroPhone.close()
        self.ui.MicroPhone2.close()
        # Открытие 1 слайда
        self.ui.ButtonStrelka1.show()
        self.ui.label_Privet.show()


    def Na_3_Slaid(self):
        # Закрытие 2 слайда
        self.ui.ButtonAV.close()
        self.ui.ButtonMogu.close()
        self.ui.label_Mogu.close()
        self.ui.ButtonStrelka2.close()
        self.ui.label_Zvuk.close()
        self.ui.Strelka_Nazad_2.close()
        # Открытие 3 слайда
        self.ui.vihod.show()
        self.ui.Strelka_Nazad.show()
        self.ui.Linia_Slaid_3.show()
        self.ui.Znak_voprosa.show()
        self.ui.Otkritb_Text.show()
        self.ui.MicroPhone.show()
        self.ui.label_loh.show()

        self.alk = 1

    def Na_1_slaid_s3(self):
        # Закрытие 3 слайда
        self.ui.label_loh.close()
        self.ui.Strelka_Nazad.close()
        self.ui.Linia_Slaid_3.close()
        self.ui.Znak_voprosa.close()
        self.ui.Otkritb_Text.close()
        self.ui.MicroPhone.close()
        self.ui.MicroPhone2.close()
        self.ui.vihod.close()
        # Открытие 1 слайда
        self.ui.label_Privet.show()
        self.ui.ButtonAV.show()
        self.ui.ButtonAV.setGeometry(QtCore.QRect(300, 50, 200, 191))
        self.ui.ButtonStrelka1.show()


    def Znak_voprosa(self):
        # Закрытие 3 слайда
        self.ui.label_loh.close()
        self.ui.Strelka_Nazad.close()
        self.ui.Linia_Slaid_3.close()
        self.ui.Znak_voprosa.close()
        self.ui.Otkritb_Text.close()
        self.ui.MicroPhone.close()
        self.ui.MicroPhone2.close()
        self.ui.Strelka_Nazad_2.close()
        self.ui.label_Zvuk.close()
        self.ui.vihod.close()

        # Открытие 2 слайда
        self.ui.ButtonAV.show()
        self.ui.ButtonAV.setGeometry(QtCore.QRect(300, 0, 200, 191))
        self.ui.ButtonMogu.show()
        self.ui.label_Mogu.show()
        self.ui.ButtonStrelka2.show()




#Открытие главного окна

app = QtWidgets.QApplication([])
application = untitled()
application.show()
app.exec()
# sys.exit(app.exec())
